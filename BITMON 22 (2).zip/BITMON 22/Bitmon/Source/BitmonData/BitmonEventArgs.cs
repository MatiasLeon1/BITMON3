﻿using System;

namespace BitmonGeneration1.Source.BitmonData
{
    public class BitmonEventArgs : EventArgs
    {
        public Bitmon bitmon;
    }

    public class GainedExpEventArgs : BitmonEventArgs
    {
        public float exp;

        public GainedExpEventArgs(Bitmon bitmon, float exp)
        {
            this.bitmon = bitmon;
            this.exp = exp;
        }
    }

    public class GainedHPEventArgs : BitmonEventArgs
    {
        public float gainedHP;

        public GainedHPEventArgs(Bitmon thisBitmon, float gainedHP)
        {
            this.bitmon = thisBitmon;
            this.gainedHP = gainedHP;
        }
    }
}
