﻿using BitmonGeneration1.Source.BitmonData;
using System;

namespace BitmonStadiumConsoleApp
{
    public static class SelectBitmon
    {
        public static Bitmon Choose()
        {
            int input = int.MinValue;

            while (input < 1 || input > 10)
            {
                Console.Clear();
                Display10Bitmon();
                Console.Write("Enter selection: ");
                while (!Int32.TryParse(Console.ReadLine(), out input))
                {
                    Console.Clear();
                    Display10Bitmon();
                    Console.Write("Enter selection: ");
                }
                
            }

            Console.Clear();
            return RentalPokemonFactory.PrimeCup(input);
        }

       

        private static void Display10Bitmon()
        {
            string line;
            for (int i = 1; i < 11; i++)
            {
                line = Display.LeftJustify(i + " | " + SpeciesData.Names[i], 11);

                Console.WriteLine(line);
            }
        }
    }
}
