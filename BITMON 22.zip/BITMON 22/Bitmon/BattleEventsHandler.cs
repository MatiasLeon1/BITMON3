﻿using BitmonGeneration1.Source.Battles;
using System;
using System.Threading;

namespace BitmonStadiumConsoleApp
{
    public static class BattleEventsHandler
    {
        public static void AttachMyBattleBitmonEventHandlers(BattleBitmon myBit)
        {
            //bitmon events
            myBit.Burned += MyBurnedEventHandler;
            myBit.Frozen += MyFrozenEventHandler;
            myBit.Paralyzed += MyParalyzedEventHandler;
            myBit.Poisoned += MyPoisonedEventHandler;
            myBit.BadlyPoisoned += MyBadlyPoisonedEventHandler;
            myBit.FellAsleep += MyFellAsleepEventHandler;
            myBit.StatusCleared += MyStatusClearedEventHandler;
            myBit.Fainted += MyFaintedEventHandler;

            //move events
            myBit.MoveUsed += MyMoveUsedEventHandler;
            myBit.MoveMissed += MoveMissedEventHandler;
            myBit.MoveSuperEffective += MoveSuperEffectiveEventHandler;
            myBit.MoveNotVeryEffective += MoveNotVeryEffectiveEventHandler;
            myBit.MoveCriticalHit += MoveCriticalHitEventHandler;
            myBit.MoveOneHitKO += MoveOneHitKOEventHandler;
            myBit.PayDayTriggered += PayDayTriggeredEventHandler;
            myBit.SolarBeamFirstTurn += MySolarBeamFirstTurnEventHandler;
            myBit.RazorWindFirstTurn += MyRazorWindFirstTurnEventHandler;
            myBit.BidingTime += MyBidingTimeEventHandler;
            myBit.BideUnleased += MyBideUnleashedEventHandler;
            myBit.FlyFirstTurn += MyFlyFirstTurnEventHandler;
            myBit.AttackContinues += MyAttackContinuesEventHandler;
            myBit.CrashDamage += MyCrashDamageEventHandler;
            myBit.HurtByRecoilDamage += MyHurtByRecoilDamageEventHandler;
            myBit.ThrashingAbout += MyThrashingAboutEventHandler;
            myBit.HyperBeamRecharging += MyHyperBeamRechargingEventHandler;
            myBit.SuckedHealth += MySuckedHealthEventHandler;
            myBit.DugAHole += MyDugAHoleEventHandler;
            myBit.SkullBashFirstTurn += MySkullBashFirstTurnEventHandler;
            myBit.SkyAttackFirstTurn += MySkyAttackFirstTurnEventHandler;
            myBit.RegainedHealth += MyRegainedHealthEventHandler;

            //battleBitmon events
            myBit.SwitchedOut += MySwitchedOutEventHandler;
            myBit.StatStageChanged += MyStatStageChangedEventHandler;
            myBit.SubstituteActivated += MySubstituteActivatedEventHandler;
            myBit.ConversionActivated += MyConversionActivatedEventHandler;
            myBit.TransformActivated += MyTransformActivatedEventHandler;
            myBit.LeechSeedActivated += MyLeechSeedActivatedEventHandler;
            myBit.LeechSeedSaps += MyLeechSeedSapsEventHandler;
            myBit.HurtFromConfusion += HurtFromConfusionEventHandler;
            myBit.Flinched += MyFlinchedEventHandler;
            myBit.FullyParalyzed += MyFullyParalyzedEventHandler;
            myBit.FrozenSolid += MyFrozenSolidEventHandler;
            myBit.FastAsleep += MyFastAsleepEventHandler;
            myBit.WokeUp += MyWokeUpEventHandler;
            myBit.Disabled += MyDisabledEventHandler;
            myBit.MoveAttemptedButIsDisabled += MyMoveAttemptedButIsDisabledEventHandler;
            myBit.Mimic += MyMimicEventHandler;
        }
        public static void AttachOpponentBattleBitmonEventHandlers(BattleBitmon enemyBit)
        {
            //bitmons events
            enemyBit.SwitchedOut += EnemySwitchedOutEventHandler;
            enemyBit.Burned += EnemyBurnedEventHandler;
            enemyBit.Frozen += EnemyFrozenEventHandler;
            enemyBit.Paralyzed += EnemyParalyzedEventHandler;
            enemyBit.Poisoned += EnemyPoisonedEventHandler;
            enemyBit.BadlyPoisoned += EnemyBadlyPoisonedEventHandler;
            enemyBit.FellAsleep += EnemyFellAsleepEventHandler;
            enemyBit.StatusCleared += EnemyStatusClearedEventHandler;
            enemyBit.Fainted += EnemyFaintedEventHandler;

            //move events
            enemyBit.MoveUsed += EnemyMoveUsedEventHandler;
            enemyBit.MoveMissed += MoveMissedEventHandler;
            enemyBit.MoveSuperEffective += MoveSuperEffectiveEventHandler;
            enemyBit.MoveNotVeryEffective += MoveNotVeryEffectiveEventHandler;
            enemyBit.MoveCriticalHit += MoveCriticalHitEventHandler;
            enemyBit.MoveOneHitKO += MoveOneHitKOEventHandler;
            enemyBit.PayDayTriggered += PayDayTriggeredEventHandler;
            enemyBit.SolarBeamFirstTurn += EnemySolarBeamFirstTurnEventHandler;
            enemyBit.RazorWindFirstTurn += EnemyRazorWindFirstTurnEventHandler;
            enemyBit.BidingTime += EnemyBidingTimeEventHandler;
            enemyBit.BideUnleased += EnemyBideUnleashedEventHandler;
            enemyBit.FlyFirstTurn += EnemyFlyFirstTurnEventHandler;
            enemyBit.AttackContinues += EnemyAttackContinuesEventHandler;
            enemyBit.CrashDamage += EnemyCrashDamageEventHandler;
            enemyBit.HurtByRecoilDamage += EnemyHurtByRecoilDamageEventHandler;
            enemyBit.ThrashingAbout += EnemyThrashingAboutEventHandler;
            enemyBit.HyperBeamRecharging += EnemyHyperBeamRechargingEventHandler;
            enemyBit.SuckedHealth += EnemySuckedHealthEventHandler;
            enemyBit.DugAHole += EnemyDugAHoleEventHandler;
            enemyBit.SkullBashFirstTurn += EnemySkullBashFirstTurnEventHandler;
            enemyBit.SkyAttackFirstTurn += EnemySkyAttackFirstTurnEventHandler;
            enemyBit.RegainedHealth += EnemyRegainedHealthEventHandler;

            //battleBitmon events
            enemyBit.StatStageChanged += EnemyStatStageChangedEventHandler;
            enemyBit.SubstituteActivated += EnemySubstituteActivatedEventHandler;
            enemyBit.ConversionActivated += EnemyConversionActivatedEventHandler;
            enemyBit.TransformActivated += EnemyTransformActivatedEventHandler;
            enemyBit.LeechSeedActivated += EnemyLeechSeedActivatedEventHandler;
            enemyBit.LeechSeedSaps += EnemyLeechSeedSapsEventHandler;
            enemyBit.HurtFromConfusion += HurtFromConfusionEventHandler;
            enemyBit.Flinched += EnemyFlinchedEventHandler;
            enemyBit.FullyParalyzed += EnemyFullyParalyzedEventHandler;
            enemyBit.FrozenSolid += EnemyFrozenSolidEventHandler;
            enemyBit.FastAsleep += EnemyFastAsleepEventHandler;
            enemyBit.WokeUp += EnemyWokeUpEventHandler;
            enemyBit.Disabled += EnemyDisabledEventHandler;
            enemyBit.MoveAttemptedButIsDisabled += EnemyMoveAttemptedButIsDisabledEventHandler;
            enemyBit.Mimic += EnemyMimicEventHandler;
        }
        public static void AttachBattleEventHandlers(Battle battle)
        {
            battle.BattleBegun += BattleBegunEventHandler;
            battle.BattleOver += BattleOverEventHandler;
            battle.MakingSelections += MakingSelectionsEventHandler;
            battle.FirstExecutionBegun += FirstExecutionBegunHandler;
            battle.FirstExecutionOver += FirstExecutionOverHandler;
            battle.SecondExecutionBegun += SecondExecutionBegunHandler;
            battle.SecondExecutionOver += SecondExecutionOverHandler;
        }




        //===================================================================================//
        //                          BATTLE EVENT HANDLERS                                    //
        //===================================================================================//
        private static void BattleBegunEventHandler(object sender, BattleEventArgs args)
        {
            Console.WriteLine("Battle has begun!");
            Thread.Sleep(2700);
            Console.Clear();
        }
        private static void BattleOverEventHandler(object sender, BattleEventArgs args)
        {
            Console.Clear();
            DisplayBitmon(args);
            Console.WriteLine();
            Console.WriteLine("Battle over!");
            Thread.Sleep(2500);
            if (args.thisBattle.IsPlayerDefeated)
            {
                Console.WriteLine("Player lost!");
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("You won!");
                Console.WriteLine();
            }
        }
        private static void MakingSelectionsEventHandler(object sender, BattleEventArgs args)
        {
            DisplayBitmon(args);
        }
        private static void FirstExecutionBegunHandler(object sender, BattleEventArgs args)
        {
            Console.Clear();
            DisplayBitmon(args);
        }
        private static void FirstExecutionOverHandler(object sender, BattleEventArgs args)
        {
            Thread.Sleep(2200);
        }
        private static void SecondExecutionBegunHandler(object sender, BattleEventArgs args)
        {
            Console.Clear();
            DisplayBitmon(args);
        }
        private static void SecondExecutionOverHandler(object sender, BattleEventArgs args)
        {
            Thread.Sleep(2200);
        }
        private static void DisplayBitmon(BattleEventArgs args)
        {
            Display.Bitmon(args.thisBattle.PlayerSide.CurrentBattleBitmon,
                            args.thisBattle.OpponentSide.CurrentBattleBitmon,
                            args.thisBattle.PlayerSide.Name,
                            args.thisBattle.OpponentSide.Name);
        }
        


        //===================================================================================//
        //                          EVENT HANDLERS                                    //
        //===================================================================================//
        private static void MyBurnedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was burned!");
        }
        private static void EnemyBurnedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was burned!");
        }
        private static void MyFrozenEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was frozen!");
        }
        private static void EnemyFrozenEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was frozen!");
        }
        private static void MyParalyzedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was paralyzed!");
        }
        private static void EnemyParalyzedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was paralyzed!");
        }
        private static void MyPoisonedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was poisoned!");
        }
        private static void EnemyPoisonedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was poisoned!");
        }
        private static void MyBadlyPoisonedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was badly poisoned!");
        }
        private static void EnemyBadlyPoisonedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was badly poisoned!");
        }
        private static void MyFellAsleepEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " fell asleep!");
        }
        private static void EnemyFellAsleepEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " fell asleep!");
        }
        private static void MyStatusClearedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + "'s status was cleared!");
        }
        private static void EnemyStatusClearedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + "'s status was cleared!");
        }
        private static void MyFaintedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " fainted!");
        }
        private static void EnemyFaintedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " fainted!");
        }
        


        //===================================================================================//
        //                           MOVE EVENT HANDLERS                                     //
        //===================================================================================//
        private static void MyMoveUsedEventHandler(MoveEventArgs args)
        {
            Console.WriteLine();
            Console.WriteLine(args.bitmon.Nickname + " used " + args.move.Name + "!");
            Thread.Sleep(1500);
        }
        private static void EnemyMoveUsedEventHandler(MoveEventArgs args)
        {
            Console.WriteLine();
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " used " + args.move.Name + "!");
            Thread.Sleep(1500);
        }
        private static void MoveMissedEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("");
        }
        private static void MoveSuperEffectiveEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("");
        }
        private static void MoveNotVeryEffectiveEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("");
        }
        private static void MoveCriticalHitEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("");
        }
        private static void MoveOneHitKOEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("");
        }
        private static void PayDayTriggeredEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("");
        }
        private static void MySolarBeamFirstTurnEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + " took in sunlight!");
        }
        private static void EnemySolarBeamFirstTurnEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " took in sunlight!");
        }
        private static void MyRazorWindFirstTurnEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " made a whirlwind!");
        }
        private static void EnemyRazorWindFirstTurnEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " made a whirlwind!");
        }
        private static void MyBidingTimeEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " is biding its time!");
        }
        private static void EnemyBidingTimeEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " is biding its time!");
        }
        private static void MyBideUnleashedEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " unleased bide!");
        }
        private static void EnemyBideUnleashedEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " unleased bide!");
        }
        private static void MyFlyFirstTurnEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " flew up high!");
        }
        private static void EnemyFlyFirstTurnEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " flew up high!");
        }
        private static void MyAttackContinuesEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + "'s attack continues!");
        }
        private static void EnemyAttackContinuesEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + "'s attack continues!");
        }
        private static void MyCrashDamageEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was hurt by crash damage!");
        }
        private static void EnemyCrashDamageEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was hurt by crash damage!");
        }
        private static void MyHurtByRecoilDamageEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was hurt by recoil damage!");
        }
        private static void EnemyHurtByRecoilDamageEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was hurt by recoil damage!");
        }
        private static void MyThrashingAboutEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " is thrashing about!");
        }
        private static void EnemyThrashingAboutEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " is thrashing about!");
        }
        private static void MyHyperBeamRechargingEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " is recharging!");
        }
        private static void EnemyHyperBeamRechargingEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " is recharging!");
        }
        private static void MySuckedHealthEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " sucked health!");
        }
        private static void EnemySuckedHealthEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " sucked health!");
        }
        private static void MyDugAHoleEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " dug a hole!");
        }
        private static void EnemyDugAHoleEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " dug a hole!");
        }
        private static void MySkullBashFirstTurnEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " withdrew its head!");
        }
        private static void EnemySkullBashFirstTurnEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " withdrew its head!");
        }
        private static void MySkyAttackFirstTurnEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " is glowing!");
        }
        private static void EnemySkyAttackFirstTurnEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " is glowing!");
        }
        private static void MyRegainedHealthEventHandler(MoveEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " regained health!");
        }
        private static void EnemyRegainedHealthEventHandler(MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " regained health!");
        }



        //===================================================================================//
        //                       BATTLE BITMON EVENT HANDLERS                               //
        //===================================================================================//
        private static void MySwitchedOutEventHandler(object sender, SwitchedOutEventArgs args)
        {
            Console.WriteLine("Come back " + args.bitmon.Nickname + "!");
            Thread.Sleep(2200);
            Console.WriteLine("Go " + args.switchIn.Nickname + "!");
            Thread.Sleep(2200);
        }
        private static void EnemySwitchedOutEventHandler(object sender, SwitchedOutEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " was withdrawn!");
            Thread.Sleep(2200);
            Console.WriteLine("Go " + args.switchIn.Nickname + "!");
            Thread.Sleep(2200);
        }
        private static void MyStatStageChangedEventHandler(object sender, BitmonGeneration1.Source.Battles.StatStageChangedEventArgs args)
        {
            string stat = args.statChanged.ToString();
            string change;
            if (args.change == 2)
            {
                change = "sharply rose!";
            }
            else if (args.change == 1)
            {
                change = "rose!";
            }
            else if (args.change == -1)
            {
                change = "decreased!";
            }
            else
            {
                change = "sharply decreased!";
            }
            Console.WriteLine(args.bitmon.Nickname + "'s " + stat + " stat " + change);
            Console.WriteLine();
        }
        private static void EnemyStatStageChangedEventHandler(object sender, BitmonGeneration1.Source.Battles.StatStageChangedEventArgs args)
        {
            string stat = args.statChanged.ToString();
            string change;
            if (args.change == 2)
            {
                change = "sharply rose!";
            }
            else if (args.change == 1)
            {
                change = "rose!";
            }
            else if (args.change == -1)
            {
                change = "decreased!";
            }
            else
            {
                change = "sharply decreased!";
            }
            Console.WriteLine("Enemy " + args.bitmon.Nickname + "'s " + stat + " stat " + change);
            Console.WriteLine();
        }
        private static void MyLeechSeedActivatedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.battleBitmon.Name + " was seeded!");
            Console.WriteLine();
        }
        private static void EnemyLeechSeedActivatedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.battleBitmon.Name + " was seeded!");
            Console.WriteLine();
        }
        private static void MyLeechSeedSapsEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Leech seed saps " + args.bitmon.Nickname);
        }
        private static void EnemyLeechSeedSapsEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Leech seed saps enemy " + args.bitmon.Nickname);
        }
        private static void MySubstituteActivatedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + " created a substitute!");
        }
        private static void EnemySubstituteActivatedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " created a substitute!");
        }
        private static void MyConversionActivatedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + " changed type!");
        }
        private static void EnemyConversionActivatedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " changed type!");
        }
        private static void MyTransformActivatedEventHandler(object sender, TransformedEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + " transformed into " + args.transformInto.Name + "!");
        }
        private static void EnemyTransformActivatedEventHandler(object sender, TransformedEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " transformed into " + args.transformInto.Name + "!");
        }
        private static void HurtFromConfusionEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("It hurt itself in confusion!");
        }
        private static void MyFlinchedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + " flinched!");
        }
        private static void EnemyFlinchedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " flinched!");
        }
        private static void MyFullyParalyzedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + " is fully paralyzed!");
        }
        private static void EnemyFullyParalyzedEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " is fully paralyzed!");
        }
        private static void MyFrozenSolidEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + " is frozen solid!");
        }
        private static void EnemyFrozenSolidEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " is frozen solid!");
        }
        private static void MyFastAsleepEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + " is fast asleep!");
        }
        private static void EnemyFastAsleepEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " is fast asleep!");
        }
        private static void MyWokeUpEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + " woke up!");
        }
        private static void EnemyWokeUpEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " woke up!");
        }
        private static void MyDisabledEventHandler(object sender, MoveEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + "'s " + args.move.Name + " was disabled!");
        }
        private static void EnemyDisabledEventHandler(object sender, MoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + "'s " + args.move.Name + " was disabled!");
        }
        private static void MyMoveAttemptedButIsDisabledEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + " is disabled!");
        }
        private static void EnemyMoveAttemptedButIsDisabledEventHandler(object sender, BattleBitmonEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " is disabled!");
        }
        private static void MyMimicEventHandler(object sender, BitmonGeneration1.Source.Battles.MimicMoveEventArgs args)
        {
            Console.WriteLine(args.bitmon.Nickname + " copied enemy " + args.opponent.Name + "'s " + args.moveMimiced.Name);
        }
        private static void EnemyMimicEventHandler(object sender, BitmonGeneration1.Source.Battles.MimicMoveEventArgs args)
        {
            Console.WriteLine("Enemy " + args.bitmon.Nickname + " copied " + args.opponent.Name + "'s " + args.moveMimiced.Name);
        }
        

    }
}
