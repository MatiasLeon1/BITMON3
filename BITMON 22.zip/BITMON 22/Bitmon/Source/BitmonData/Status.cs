﻿namespace BitmonGeneration1.Source.BitmonData
{
    public enum Status
    {
        Null,
        Burn,
        Freeze,
        Paralysis,
        Poison,
        BadlyPoisoned,
        Sleep,
        Fainted
    }
}
