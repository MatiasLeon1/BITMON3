﻿using BitmonGeneration1.Source.Battles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BitmonGeneration1.Source.Moves.Transitive.Attack.OneTurnMultiHit
{

    //3
    public sealed class DoubleSlap : OneTurnMultiHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                SetRandomNumberOfHits();

                this.UpdateEffectiveness(defender);
                this.UpdateCritFlag(user);

                float damageAmount = CalcDamage(user, defender);
                this.ExecuteMultiHitDamage(defender, damageAmount);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public DoubleSlap() : base(3, "Double Slap", Type.Normal,  85f, 15f, Category.PHYSICAL) { }
    }

    //4
    public sealed class CometPunch : OneTurnMultiHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                SetRandomNumberOfHits();

                this.UpdateEffectiveness(defender);
                this.UpdateCritFlag(user);

                float damageAmount = CalcDamage(user, defender);
                this.ExecuteMultiHitDamage(defender, damageAmount);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public CometPunch() : base(4, "Comet Punch", Type.Normal,  85f, 18f, Category.PHYSICAL) { }
    }


    //24
    public sealed class DoubleKick : OneTurnMultiHitAttackMove
    {
        public sealed override void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectiveness(defender);
                UpdateCritFlag(user);
                float damageAmount = CalcDamage(user, defender);
                this.ExecuteMultiHitDamage(defender, damageAmount);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public DoubleKick() : base(24, "Double Kick", Type.Fighting,  100f, 30f, Category.PHYSICAL)
        {
            numberOfHits = 2;
        }
    }

    //31
    public sealed class FuryAttack : OneTurnMultiHitAttackMove
    {
        public sealed override void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                SetRandomNumberOfHits();
                UpdateEffectiveness(defender);
                UpdateCritFlag(user);
                float damageAmount = CalcDamage(user, defender);
                this.ExecuteMultiHitDamage(defender, damageAmount);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public FuryAttack() : base(31, "Fury Attack", Type.Normal, 85f, 15f, Category.PHYSICAL) { }
    }

    //41
    public sealed class Twineedle : OneTurnMultiHitAttackMove
    {
        public sealed override void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectiveness(defender);
                UpdateCritFlag(user);
                float damageAmount = CalcDamage(user, defender);
                ExecuteMultiHitDamageAndAttemptPoison(defender, damageAmount);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public Twineedle() : base(41, "Twineedle", Type.Poison,  100f, 25f, Category.PHYSICAL)
        {
            numberOfHits = 2;
        }
    }

    //42
    public sealed class PinMissile : OneTurnMultiHitAttackMove
    {
        public sealed override void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                SetRandomNumberOfHits();
                UpdateEffectiveness(defender);
                UpdateCritFlag(user);
                float damageAmount = CalcDamage(user, defender);
                this.ExecuteMultiHitDamage(defender, damageAmount);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public PinMissile() : base(42, "Pin Missile", Type.Bug,  85f, 14f, Category.PHYSICAL) { }
    }

    //131
    public sealed class SpikeCannon : OneTurnMultiHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                SetRandomNumberOfHits();

                this.UpdateEffectiveness(defender);
                this.UpdateCritFlag(user);

                float damageAmount = CalcDamage(user, defender);
                this.ExecuteMultiHitDamage(defender, damageAmount);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public SpikeCannon() : base(131, "Spike Cannon", Type.Normal,  100f, 20f, Category.PHYSICAL) { }
    }

    //140
    public sealed class Barrage : OneTurnMultiHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                SetRandomNumberOfHits();

                this.UpdateEffectiveness(defender);
                this.UpdateCritFlag(user);

                float damageAmount = CalcDamage(user, defender);
                this.ExecuteMultiHitDamage(defender, damageAmount);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public Barrage() : base(140, "Barrage", Type.Normal,  85f, 15f, Category.PHYSICAL) { }
    }

    //154
    public sealed class FurySwipes : OneTurnMultiHitAttackMove
    {
        public override sealed void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                SetRandomNumberOfHits();

                this.UpdateEffectiveness(defender);
                this.UpdateCritFlag(user);

                float damageAmount = CalcDamage(user, defender);
                this.ExecuteMultiHitDamage(defender, damageAmount);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public FurySwipes() : base(154, "Fury Swipes", Type.Normal,  80f, 18f, Category.PHYSICAL) { }
    }


    //155
    public sealed class Bonemerang : OneTurnMultiHitAttackMove
    {
        public sealed override void ExecuteAndUpdate(BattleBitmon user, BattleBitmon defender)
        {
            OnUsed();
            if (this.HasNoEffect(defender))
            {
                OnNoEffect();
            }
            else if (this.IsAMiss(user, defender))
            {
                OnMissed();
            }
            else
            {
                UpdateEffectiveness(defender);
                UpdateCritFlag(user);
                float damageAmount = CalcDamage(user, defender);
                ExecuteMultiHitDamageAndAttemptPoison(defender, damageAmount);
            }
            SetLastMoveAndMirrorMove(user, defender);
            
        }

        public Bonemerang() : base(155, "Bonemerang", Type.Ground,  90f, 50f, Category.PHYSICAL)
        {
            numberOfHits = 2;
        }
    }

}
